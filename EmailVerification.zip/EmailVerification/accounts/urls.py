from django.urls import path,include
from .views import *
urlpatterns = [
    path('',home,name="home"),
    path('accounts/login/' , login_attempt , name="login_attempt"),
    path('register/' , register_attempt , name="register_attempt"),
    path('token' , token_send , name="token_send"),
    path('success' , success , name='success'),
    path('error' , error_page , name="error"),
    path('verify/<auth_token>' , verify , name="verify"),
    path('logout/',logout_view,name="logout_view"),
    
]
